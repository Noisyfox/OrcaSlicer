from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
def commands(path):
    with ZipFile(path) as archive:
        names = [name for name in archive.namelist() if name.endswith(".gcode")]
        assert len(names) == 1, names
        text = archive.read(names[0]).decode("utf-8")
    return [cmd for line in text.splitlines() if (cmd := line.split(";", 1)[0].strip())]

before = commands(root / "plate-2.gcode.3mf")
after = commands(root / "plate-2-fixed.gcode.3mf")
assert before == after, "Generated G-code commands differ"
print(f"PASS: {len(after)} non-comment G-code commands are identical")
